package com.cg.payroll.services;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.PayrollDAOServicesImpl;

public class PayrollServicesImpl {
	private PayrollDAOServicesImpl daoServices;
	public PayrollServicesImpl(){
		daoServices =new PayrollDAOServicesImpl();
	}
	public int acceptAssociateDetails(String firstName, String lastName,String emailId,String department, String designation,String pancard, int yearlyInvestmentUnder80C, 
			float basicSalary,float epf, float companyPf,int accountNumber, String bankName, String ifscCode){ 
		//	Associate associate=new Associate(yearlyInvestmentUnder80C, firstName, lastName, department, designation, pancard, emailId,new Salary(basicSalary, epf, companyPf),
		//		new BankDetails(accountNumber, bankName, ifscCode));
		//	int associateId=daoServices.insertAssociate(associate);
		//	return associateId;
		return daoServices.insertAssociate(new Associate(yearlyInvestmentUnder80C, firstName, lastName, department, designation, pancard, emailId, new Salary(basicSalary, epf, companyPf), new BankDetails(accountNumber, bankName, ifscCode)));
	}
	public double calculateNetSalary(int associateId){
		Associate associate=this.getAssociateDetails(associateId);
		if(associate!=null)
		{
			associate.getSalary().setPersonalAllowance((float)0.3 * associate.getSalary().getBasicSalary());
			associate.getSalary().setConveyenceAllowance((float)0.2 * associate.getSalary().getBasicSalary());
			associate.getSalary().setOtherAllowance((float)0.1 *associate.getSalary().getBasicSalary());
			associate.getSalary().setHra((float)0.25 * associate.getSalary().getBasicSalary());
			associate.getSalary().setGratuity((float)0.05 *associate.getSalary().getBasicSalary());
			associate.getSalary().setGrossSalary(associate.getSalary().getBasicSalary()+associate.getSalary().getPersonalAllowance() + associate.getSalary().getConveyenceAllowance() +associate.getSalary().getOtherAllowance() + associate.getSalary().getHra()+ associate.getSalary().getCompanyPf());
			double annualSalary = associate.getSalary().getGrossSalary() * 12;
			double nonTaxable=(associate.getSalary().getEpf()+associate.getSalary().getCompanyPf())*12 +associate.getYearlyInvestmentUnder80C();
			double annualTax=0;
			if(nonTaxable>150000)
			nonTaxable=150000;
			if(annualSalary<=250000)
			annualTax = 0;
			else if(annualSalary>250000&&annualSalary<=500000){
			if(annualSalary-nonTaxable-250000>0)
			annualTax=0.1*(annualSalary-nonTaxable-250000);
			else
			annualTax = 0;
			}
			else if(annualSalary>500000&&annualSalary<=1000000)
			annualTax=0.1*(250000-nonTaxable)+0.2*(annualSalary-500000);
			else 
			annualTax=(0.1*(250000-nonTaxable))+(0.2*500000)+0.3*(annualSalary-1000000);
			associate.getSalary().setMonthlyTax((float)annualTax/12);
			associate.getSalary().setNetSalary(associate.getSalary().getGrossSalary()-associate.getSalary().getMonthlyTax()-associate.getSalary().getEpf()-associate.getSalary().getCompanyPf());
			daoServices.updateAssociate(associate);
			return associate.getSalary().getNetSalary();
		}
		return 0;
	}
	public Associate getAssociateDetails(int associateId){
		return daoServices.getAssociate(associateId);

	}
	public Associate[]getAllAssociateDetails(){

		return daoServices.getAssociates();
	}
}