package com.cg.payroll.main;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.PayrollDAOServicesImpl;
import com.cg.payroll.services.PayrollServicesImpl;

public class MainClass {

	public static void main(String[] args) {
		PayrollServicesImpl payrollServices=new PayrollServicesImpl();
		int associateId=payrollServices.acceptAssociateDetails("sindhu", "kalakonda", "a.com", "java", "analyst", "e688", 0, 300000, 12000, 12000, 3456, "hdfc", "hdfc101");
		int associateId1=payrollServices.acceptAssociateDetails("vyuha", "kalakonda", "a.com", "java", "analyst", "e688", 1465, 100, 77, 67, 3456, "hdfc", "hdfc101");
		System.out.println(associateId);
		System.out.println(payrollServices.getAssociateDetails(associateId).getFirstName());
		System.out.println(payrollServices.getAssociateDetails(associateId1).getFirstName());
		double netSalary=payrollServices.calculateNetSalary(associateId);
		System.out.println("net salary is "+payrollServices.getAssociateDetails(associateId).getSalary().getNetSalary());
	}
}